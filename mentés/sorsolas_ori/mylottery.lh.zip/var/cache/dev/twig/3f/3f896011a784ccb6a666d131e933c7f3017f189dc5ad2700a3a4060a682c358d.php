<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* homepage/frontend/index.html.twig */
class __TwigTemplate_6e35f4af0b333a788e1c7e7d36edcfd9130c4eeb714778d8799819cb569d7bd6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "homepage/layout/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "homepage/frontend/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "homepage/frontend/index.html.twig"));

        $this->parent = $this->loadTemplate("homepage/layout/layout.html.twig", "homepage/frontend/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello FrontendController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
<!-- Top section -->
<section id=\"topStripe\">
  <div class=\"container\" style=\"width:95%; max-width: 110rem\">
    <div class=\"row\">
      <div class=\"col-5\">
        <div id=\"topMenu\">
          <ul>
            <li><a href=\"#\">";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Home", [], "messages");
        echo "</a></li>
            <li><a href=\"#\">";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("About Us", [], "messages");
        echo "</a></li>
            <li><a href=\"#\">";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Rewards", [], "messages");
        echo "</a></li>
            <li><a href=\"#\">";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("News", [], "messages");
        echo "</a></li>
            <li><a href=\"#\">";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Contact Us", [], "messages");
        echo "</a></li>
          <ul>
        </div>      
      </div>
      <div class=\"col-2 topLogo\" style=\"text-align: center;\">

          <a href=\"\"><img src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/logo.png"), "html", null, true);
        echo "\"></a>


      </div>
      <div class=\"col-5\" style=\"text-align: right\">
        <a class=\"btn btnTOne\" href=\"#\">Login</a>
        <a class=\"btn btnTTwo\"  href=\"#\">Sign Up</a>
      </div>

</section>





   <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-3\">
          -- This content will take up 3/12 (or 1/4) of the container -->
        </div>
        <div class=\"col-3\">
          -- This content will take up 3/12 (or 1/4) of the container --> #}
        </div>
        <div class=\"col-6\">
          - This content will take up 6/12 (or 1/2) of the container -->
        </div>
      </div>
    </div>
          



<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

<div class=\"example-wrapper\">
    <h1>Hello ";
        // line 62
        echo twig_escape_filter($this->env, (isset($context["controller_name"]) || array_key_exists("controller_name", $context) ? $context["controller_name"] : (function () { throw new RuntimeError('Variable "controller_name" does not exist.', 62, $this->source); })()), "html", null, true);
        echo "! ✅</h1>

    This friendly message is coming from:
    <ul>
        <li>Your controller at <code><a href=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\CodeExtension']->getFileLink("E:/VirtuaHosts/mylottery.lh/src/Controller/Homepage/FrontendController.php", 0), "html", null, true);
        echo "\">src/Controller/Homepage/FrontendController.php</a></code></li>
        <li>Your template at <code><a href=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\CodeExtension']->getFileLink("E:/VirtuaHosts/mylottery.lh/templates/homepage/frontend/index.html.twig", 0), "html", null, true);
        echo "\">templates/homepage/frontend/index.html.twig</a></code></li>
    </ul>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "homepage/frontend/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  175 => 67,  171 => 66,  164 => 62,  123 => 24,  114 => 18,  110 => 17,  106 => 16,  102 => 15,  98 => 14,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'homepage/layout/layout.html.twig' %}

{% block title %}Hello FrontendController!{% endblock %}

{% block body %}

<!-- Top section -->
<section id=\"topStripe\">
  <div class=\"container\" style=\"width:95%; max-width: 110rem\">
    <div class=\"row\">
      <div class=\"col-5\">
        <div id=\"topMenu\">
          <ul>
            <li><a href=\"#\">{% trans %}Home{% endtrans %}</a></li>
            <li><a href=\"#\">{% trans %}About Us{% endtrans %}</a></li>
            <li><a href=\"#\">{% trans %}Rewards{% endtrans %}</a></li>
            <li><a href=\"#\">{% trans %}News{% endtrans %}</a></li>
            <li><a href=\"#\">{% trans %}Contact Us{% endtrans %}</a></li>
          <ul>
        </div>      
      </div>
      <div class=\"col-2 topLogo\" style=\"text-align: center;\">

          <a href=\"\"><img src=\"{{asset('images/logo.png')}}\"></a>


      </div>
      <div class=\"col-5\" style=\"text-align: right\">
        <a class=\"btn btnTOne\" href=\"#\">Login</a>
        <a class=\"btn btnTTwo\"  href=\"#\">Sign Up</a>
      </div>

</section>





   <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-3\">
          -- This content will take up 3/12 (or 1/4) of the container -->
        </div>
        <div class=\"col-3\">
          -- This content will take up 3/12 (or 1/4) of the container --> #}
        </div>
        <div class=\"col-6\">
          - This content will take up 6/12 (or 1/2) of the container -->
        </div>
      </div>
    </div>
          



<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

<div class=\"example-wrapper\">
    <h1>Hello {{ controller_name }}! ✅</h1>

    This friendly message is coming from:
    <ul>
        <li>Your controller at <code><a href=\"{{ 'E:/VirtuaHosts/mylottery.lh/src/Controller/Homepage/FrontendController.php'|file_link(0) }}\">src/Controller/Homepage/FrontendController.php</a></code></li>
        <li>Your template at <code><a href=\"{{ 'E:/VirtuaHosts/mylottery.lh/templates/homepage/frontend/index.html.twig'|file_link(0) }}\">templates/homepage/frontend/index.html.twig</a></code></li>
    </ul>
</div>
{% endblock %}
", "homepage/frontend/index.html.twig", "E:\\VirtuaHosts\\mylottery.lh\\templates\\homepage\\frontend\\index.html.twig");
    }
}
